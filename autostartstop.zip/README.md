## Features
- The code provides the following automated features:
	-  start and stop of the AWS EC2 and RDS instances for a specified time period.
	- setting desired number of EC2 instaces in an autoscaling group as 0 for a specified time period.
	- setting desired number of tasks of a service in an ECS Cluster as 0 for a specified time period.

## Requirements
Add the following tags in the AWS resouces:

Key  | Value
------------- | -------------
Auto-Start-Stop  | true/false
Schedule | HHMM;HHMM;utc;N-N or HHMM;HHMM;utc;N,N or HHMM;HHMM;utc;N or HHMM;HHMM;utc;N,N-N or HHMM;HHMM;utc;N-N,N
Override  | HHMM;HHMM;utc;N-N or HHMM;HHMM;utc;N,N or HHMM;HHMM;utc;N or HHMM;HHMM;utc;N,N-N or HHMM;HHMM;utc;N-N,N

- Key: 'AutoStartStop' should be true in order to automate the start/stop of the resource.
- Key: 'Schedule' schedules the automation based on the specified value as per the format.
- Key: 'Override' schedules the automation based on the specified value as per the format over the Schedule Key.
where :-
	HH(Hour in 24 hrs format),
	MM(Minute format),
	N(day of a week)
	utc is time zone for Greenwich meridian timezone

NOTE: This function supports utc time zone only till now.

0 - Sunday
6- Saturday

#### Schedule/Override Example:

    0800;1700;utc;1-5
    
For an EC2 instance, the above schedule value will keep the instance running from 8 AM to 6 PM  from Monday to Friday.

    2000;2200;utc;3
    
For an EC2 instance, the above schedule value will keep the instance running from 8 PM to 11 PM  for Wednesday only.

    1800;2100;utc;1,3,5

For an EC2 instance, the above schedule value will keep the instance running from 6 PM to 10 PM on Monday, Wednesday, Friday.

    1000;1900;utc;1,3,5-0

For an EC2 instance, the above schedule value will keep the instance running from 10 AM to 8 PM on Monday, Wednesday, Friday-Sunday.

    2200;0200;utc;1,3,5

For an EC2 instance, the above schedule value will keep the instance running from 10 PM to 2 AM on Monday, Wednesday, Friday and there next days as per the time in the Tag Value.

## Key Points
- 'Override' Key is also like 'Schedule' Key which can be used for a bypass the Schedule Tag value and using the Override Tag Value. For eg: If this week you don't have to use the general case of usage the traffic hours will be more so use override tag for these days by simply adding in the tags and the resources will run according to this tag till it is there when you remove it they will come back to schedule tag.
- The tags are placed on ECS Cluster and the name of the service need to be specified as an env variable.
- The min and desired count of an autoscaling group need to be specified as an env variable.

## Execution Example

Create  zip file of the git repository:

```bash 
zip -r function.zip ./* 
 ```

Creating Lambda function automated-backup:

```bash
aws lambda create-function --function-name automated-backup --runtime python2.7 --handler main.lambda_handler --zip-file fileb://function.zip --role <role-arn> --environment Variables="{ECS_SVC_PATTERN=nginx,ECS_DESIRED_COUNT=0,ASG_DESIRED_CAPACITY=0,ASG_MIN_CAPACITY=0}" --timeout 50 --memory-size 256 --publish
```
#### Lambda Environment Variables:
- The function contains environment variables to be passed.
    - ECS_SVC_PATTERN=string pattern of the ECS service on which the desired count will be applied. However the tags are applied on the ECS cluster. 
    - ECS_DESIRED_COUNT=(integer value) number of tasks to be provided.
    - ASG_MIN_CAPACITY=(integer value) minimum count of the number of instances in the ASG.
    - ASG_DESIRED_CAPACITY=(integer value) desired count of the number of instances in the ASG.



Role Creation:

```bash
Coming soon
```
