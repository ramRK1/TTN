#Maintainer Bhagvatula Nipun && Ram kamra
from modules.ec2 import EC2

import time

def lambda_handler(event, context):
    EC2obj = EC2()
    EC2obj.listing(simulate=True)
