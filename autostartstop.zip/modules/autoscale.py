from .client import Client
import json
import os
import re
from time import strftime
import time
flag = 0
current_time = int(strftime("%H"))
class AutoScaleTags:

    def __init__(self, client,info):
        self.client = client
        self.MIN_CAPACITY=os.environ['ASG_MIN_CAPACITY']
        self.DESIRED_CAPACITY=os.environ['ASG_DESIRED_CAPACITY']
        self.asg_name = info.get('AutoScalingGroupName')
        self.tags = info.get('Tags')
        self.tag_check()

    def tag_check(self):
        global flag
        for j in self.tags:
            if j['Key'] == 'AutoStartStop' and j['Value'] == 'true':
                for k in self.tags:
                    if k['Key'] == 'Schedule' or k['Key'] == 'Override':
                        flag = flag + 1
                        #print("flag = ", flag)
                for k in self.tags:
                    if k['Key'] == 'Override':
                        self.override()
                    if k['Key'] == 'Schedule':
                        time.sleep(3)
                        rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                        if rex.match(k['Value']):
                            timestamp=self.time_split(k['Value'],'_')
                            now=self.time_split(timestamp[0],':')
                            start_hour=int(now[0])
                            end_hour=int(now[1])
                            week=self.time_split(timestamp[1],'-')
                            startweek=int(week[0])
                            endweek=int(week[1])
                            if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                if start_hour<=end_hour:
                                    if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                        #print("schedule start")
                                        self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=int(self.MIN_CAPACITY),DesiredCapacity=int(self.DESIRED_CAPACITY))
                                    else:
                                        if flag  > 1:
                                            #print("Checking Override")
                                            for x in self.tags:
                                                if x['Key']=='Override':
                                                    timestamp1=self.time_split(x['Value'],'_')
                                                    #print(timestamp1)
                                                    now1=self.time_split(timestamp1[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    #print(x['Value'],start_hour1,end_hour1)
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                                    else:
                                                        #print("2 day format")
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                else:
                                    time_stamps=[]
                                    for i in range(start_hour,24):
                                        time_stamps.append(i)
                                    for i in range(0,end_hour+1):
                                        time_stamps.append(i)
                                    #print(time_stamps)
                                    #print("Current time", current_time)
                                    if current_time in time_stamps:
                                        #print("Not running. Going to start")
                                        self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=int(self.MIN_CAPACITY),DesiredCapacity=int(self.DESIRED_CAPACITY))
                                    else:
                                        if flag  > 1:
                                            #print("Checking Override")
                                            for x in self.tags:
                                                if x['Key']=='Override':
                                                    timestamp=self.time_split(x['Value'],'_')
                                                    now1=self.time_split(timestamp[0],':')
                                                    start_hour1=int(now[0])
                                                    end_hour1=int(now[1])
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                                    else:
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                            else:
                                res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                if des_count>0:
                                    break
                                elif des_count==0:
                                    self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)

    def override(self):
        time.sleep(3)
        for j in self.tags:
            if j['Key'] == 'AutoStartStop' and j['Value'] == 'true':
                for k in self.tags:
                    if k['Key'] == 'Override':
                        rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                        if rex.match(k['Value']):
                            timestamp=self.time_split(k['Value'],'_')
                            now=self.time_split(timestamp[0],':')
                            start_hour=int(now[0])
                            end_hour=int(now[1])
                            week=self.time_split(timestamp[1],'-')
                            startweek=int(week[0])
                            endweek=int(week[1])
                            if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                if start_hour<=end_hour:
                                    if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                        #print("override start")
                                        self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=int(self.MIN_CAPACITY),DesiredCapacity=int(self.DESIRED_CAPACITY))
                                    else:
                                        if flag  > 1:
                                            #print("Checking Schedule")
                                            for x in self.tags:
                                                if x['Key']=='Schedule':
                                                    timestamp1=self.time_split(x['Value'],'_')
                                                    #print(timestamp1)
                                                    now1=self.time_split(timestamp1[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    #print(x['Value'],start_hour1,end_hour1)
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                                    else:
                                                        #print("2 day format")
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                else:
                                    time_stamps=[]
                                    for i in range(start_hour,24):
                                        time_stamps.append(i)
                                    for i in range(0,end_hour+1):
                                        time_stamps.append(i)
                                    #print(time_stamps)
                                    if current_time in time_stamps:
                                        self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=int(self.MIN_CAPACITY),DesiredCapacity=int(self.DESIRED_CAPACITY))
                                    else:
                                        if flag  > 1:
                                            #print("Checkinig Schedule")
                                            for x in self.tags:
                                                if x['Key']=='Schedule':
                                                    timestamp=self.time_split(x['Value'],'_')
                                                    now1=self.time_split(timestamp[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                                                    else:
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                                            des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                                            if des_count>0:
                                                                break
                                                            elif des_count==0:
                                                                self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)
                            else:
                                res = self.client.describe_auto_scaling_groups(AutoScalingGroupNames=[self.asg_name])
                                des_count=res['AutoScalingGroups'][0]['DesiredCapacity']
                                if des_count>0:
                                    break
                                elif des_count==0:
                                    self.client.update_auto_scaling_group(AutoScalingGroupName = self.asg_name,MinSize=1,DesiredCapacity=1)       
         
    def time_split(self,input_time,x):
        splitted=input_time.split(x)
        return splitted

class AutoScale(Client,object):
    
    def __init__(self,aws_profile=None,aws_default_region=None):
        super(AutoScale,self).__init__(aws_profile=aws_profile,aws_default_region=aws_default_region)
        self.client = self.session.client('autoscaling')
    
    def _describe_auto_scaling(self):
        pager = self.client.get_paginator('describe_auto_scaling_groups')
        for page in pager.paginate():
            for r in page['AutoScalingGroups']:
                AutoScaleTags(self.client,r)
    
    def list1(self):
        return self._describe_auto_scaling()

