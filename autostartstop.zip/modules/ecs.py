from .client import Client
import os
import re
from time import strftime
import time
flag = 0
current_time = int(strftime("%H"))
class ClusterTags:
    def __init__(self, client, arn):
        self.client = client
        self.raw_arn = arn
        self.PATTERN=os.environ['ECS_SVC_PATTERN']
        self.DESIRED_COUNT=int(os.environ['ECS_DESIRED_COUNT'])
        self.tag_check()

    def tag_check(self):
        global flag
        res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
        for j in res['tags']:
            if j['key'] == 'AutoStartStop' and j['value'] == 'true':
                for k in res['tags']:
                    if k['key'] == 'Override' or k['key'] == 'Schedule':
                        flag = flag + 1
                        #print("flag = ", flag)
                for k in res['tags']:
                    if k['key'] == 'Override':
                        self.override()
                    if k['key'] == 'Schedule':
                        time.sleep(3)
                        rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                        if rex.match(k['value']):
                            timestamp=self.time_split(k['value'],'_')
                            now=self.time_split(timestamp[0],':')
                            start_hour=int(now[0])
                            end_hour=int(now[1])
                            week=self.time_split(timestamp[1],'-')
                            startweek=int(week[0])
                            endweek=int(week[1])
                            if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                if start_hour<=end_hour:
                                    if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                        #print("schedule start")
                                        res = self.client.list_services(cluster=self.raw_arn)
                                        for j in res['serviceArns']:
                                            if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=self.DESIRED_COUNT)
                                    else:
                                        if flag  > 1:
                                            #print("Checking Override")
                                            res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
                                            for x in res['tags']:
                                                if x['key']=='Override':
                                                    timestamp1=self.time_split(x['value'],'_')
                                                    #print(timestamp1)
                                                    now1=self.time_split(timestamp1[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    #print(x['value'],start_hour1,end_hour1)
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)  
                                                    else:
                                                        #print("2 day format")
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    elif des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)

                                else:
                                    time_stamps=[]
                                    for i in range(start_hour,24):
                                        time_stamps.append(i)
                                    for i in range(0,end_hour+1):
                                        time_stamps.append(i)
                                    #print(time_stamps)
                                    #print("Current time", current_time)
                                    if current_time in time_stamps:
                                        #print("Sttart instance pleaseeeeeeee")
                                        #print("Not running. Going to start")
                                        res = self.client.list_services(cluster=self.raw_arn)
                                        for j in res['serviceArns']:
                                            if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=self.DESIRED_COUNT)
                                    else:
                                        if flag  > 1:
                                            #print("Checking Override")
                                            res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
                                            for x in res['tags']:
                                                if x['key']=='Override':
                                                    timestamp=self.time_split(x['value'],'_')
                                                    now1=self.time_split(timestamp[0],':')
                                                    start_hour1=int(now[0])
                                                    end_hour1=int(now[1])
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)
                                                    else:
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("Schedule stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)
                            else:
                                res = self.client.list_services(cluster=self.raw_arn)
                                for j in res['serviceArns']:
                                    if j.partition('/')[-1].find(self.PATTERN) != -1:
                                        res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                        des_count=res1['services'][0]['desiredCount']
                                        if des_count>0:
                                            break
                                        if des_count==0:
                                            update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)              

    def override(self):
        time.sleep(3)
        res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
        for j in res['tags']:
            if j['key'] == 'AutoStartStop' and j['value'] == 'true':
                for k in res['tags']:
                    if k['key'] == 'Override':
                        rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                        if rex.match(k['value']):
                            timestamp=self.time_split(k['value'],'_')
                            now=self.time_split(timestamp[0],':')
                            start_hour=int(now[0])
                            end_hour=int(now[1])
                            week=self.time_split(timestamp[1],'-')
                            startweek=int(week[0])
                            endweek=int(week[1])
                            if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                if start_hour<=end_hour:
                                    if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                        #print("override start")
                                        res = self.client.list_services(cluster=self.raw_arn)
                                        for j in res['serviceArns']:
                                            if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=self.DESIRED_COUNT)
                                    else:
                                        if flag  > 1:
                                            #print("Checking Schedule")
                                            res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
                                            for x in res['tags']:
                                                if x['key']=='Schedule':
                                                    timestamp1=self.time_split(x['value'],'_')
                                                    #print(timestamp1)
                                                    now1=self.time_split(timestamp1[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    #print(x['value'],start_hour1,end_hour1)
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)  
                                                    else:
                                                        #print("2 day format")
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)

                                else:
                                    time_stamps=[]
                                    for i in range(start_hour,24):
                                        time_stamps.append(i)
                                    for i in range(0,end_hour+1):
                                        time_stamps.append(i)
                                    #print(time_stamps)

                                    if current_time in time_stamps:
                                        res = self.client.list_services(cluster=self.raw_arn)
                                        for j in res['serviceArns']:
                                            if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=self.DESIRED_COUNT)
                                    else:
                                        if flag  > 1:
                                            #print("Checkinig Schedule")
                                            res=self.client.list_tags_for_resource(resourceArn=self.raw_arn)
                                            for x in res['tags']:
                                                if x['key']=='Schedule':
                                                    timestamp=self.time_split(x['value'],'_')
                                                    now1=self.time_split(timestamp[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)  
                                                    else:
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            #print("override stop")
                                                            res = self.client.list_services(cluster=self.raw_arn)
                                                            for j in res['serviceArns']:
                                                                if j.partition('/')[-1].find(self.PATTERN) != -1:
                                                                    res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                                                    des_count=res1['services'][0]['desiredCount']
                                                                    if des_count>0:
                                                                        break
                                                                    if des_count==0:
                                                                        update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)
                            else:
                                res = self.client.list_services(cluster=self.raw_arn)
                                for j in res['serviceArns']:
                                    if j.partition('/')[-1].find(self.PATTERN) != -1:
                                        res1=self.client.describe_services(cluster=self.raw_arn,services=[j])
                                        des_count=res1['services'][0]['desiredCount']
                                        if des_count>0:
                                            break
                                        if des_count==0:
                                            update_response=self.client.update_service(cluster=self.raw_arn,service=j,desiredCount=1)
                        

    def time_split(self,input_time,x):
        splitted=input_time.split(x)
        return splitted

class ECS(Client,object):
    def __init__(self,aws_profile=None,aws_default_region=None):
        super(ECS, self).__init__(aws_profile=aws_profile,aws_default_region=aws_default_region)
        self.client = self.session.client('ecs')

    def list_clusters(self):
        cluster_arns = []
        pager = self.client.get_paginator('list_clusters')
        for page in pager.paginate():
            for arn in page['clusterArns']:
                ClusterTags(self.client, arn)  

    def list1(self):
        return self.list_clusters()
