from .client import Client
import os, re, time
from time import strftime
from datetime import datetime
Override = False
current_time = int(datetime.utcnow().strftime("%H"))
class Ec2Tags:
    def __init__(self, client, simulate, info, simulate_start, simulate_stop, instances):
        self.client = client
        self.instance_id = info.get('InstanceId')
        if simulate == False:
            print(self.instance_id)
        self.tags = info.get('Tags')
        self.tag_check(simulate, simulate_start, simulate_stop, instances)

    def tag_check(self, simulate, simulate_start, simulate_stop, instances):
        global Override
        flag = 0
        
        for k in self.tags:
            if k['Key'].lower() == 'override':
                Override = True
                flag += 1
                break

            if k['Key'].lower() == 'schedule':
                schedule_value = k['Value']
                flag += 1
            
        if flag == 0:
            print("No tag as Schedule or Override")
            return

        run_days = []
        if Override == True:
            self.override(simulate, simulate_start, simulate_stop, instances, run_days)
            return
        
        res=self.client.describe_instances(InstanceIds=[self.instance_id])
        status=res['Reservations'][0]['Instances'][0]['State']['Name']
        
        if status == "stopping" or status == "pending":
            instances.append(self.instance_id)
            return
        if status == "stopped":
            rex = re.compile("^[0-9]{4};[0-9]{4};utc;((([0-6],){0,}[0-6]-[0-6])|([0-6]-[0-6](,[0-6]){0,})|(([0-6],){0,}[0-6])|([0-6]-[0-6])|all)$")
            if rex.match(schedule_value):
                timestamp=self.time_split(schedule_value,';')
                start_hour= int(timestamp[0][:2])
                end_hour=int(timestamp[1][:2])
                if timestamp[3] == 'all':
                    run_days = [0,1,2,3,4,5,6]
                else:
                    for i in timestamp[3].split(","):
                        if '-' in i:
                            start,stop = i.split("-")
                            for j in range(7):
                                day = (int(start) + j)%7
                                if day == int(stop):
                                    run_days.append(day)
                                    break
                                else:
                                    run_days.append(day)
                        else:
                            run_days.append(int(i))
                    #########################################################
                if int(strftime("%w")) in run_days:
                    if start_hour<=end_hour:
                        if int(current_time) >= start_hour and int(current_time) <= end_hour:
                            if simulate == True:
                                simulate_start.append(self.instance_id)
                            else:
                                print("starting instance")
                                self.client.start_instances(InstanceIds=[self.instance_id])               
                    else:
                        time_stamps=[]
                        for i in range(start_hour,24):
                            time_stamps.append(i)
                        for i in range(0,end_hour+1):
                            time_stamps.append(i)
                        if current_time in time_stamps:
                            if simulate == True:
                                simulate_start.append(self.instance_id)
                            else:
                                print("starting instance")
                                self.client.start_instances(InstanceIds=[self.instance_id])
            else:
                print("Please enter a proper Schedule Tag Value")

        elif status == 'running':
            rex = re.compile("^[0-9]{4};[0-9]{4};utc;((([0-6],){0,}[0-6]-[0-6])|([0-6]-[0-6](,[0-6]){0,})|(([0-6],){0,}[0-6])|([0-6]-[0-6])|all)$")
            if rex.match(schedule_value):
                timestamp=self.time_split(schedule_value,';')
                start_hour= int(timestamp[0][:2])
                end_hour=int(timestamp[1][:2])
                if timestamp[3] == 'all':
                    run_days = [0,1,2,3,4,5,6]
                else:
                    for i in timestamp[3].split(","):
                        if '-' in i:
                            start,stop = i.split("-")
                            for j in range(7):
                                day = (int(start) + j)%7
                                if day == int(stop):
                                    run_days.append(day)
                                    break
                                else:
                                    run_days.append(day)
                        else:
                            run_days.append(int(i))
                    #########################################################
                if int(strftime("%w")) not in run_days:
                    k = int(strftime("%w"))-1
                    if k == -1:
                        k = 6
                    if k in run_days:
                        if start_hour>end_hour:
                            time_stamps=[]
                            for i in range(0,end_hour+1):
                                time_stamps.append(i)
                            if current_time not in time_stamps:
                                if simulate == True:
                                    simulate_stop.append(self.instance_id)
                                else:
                                    print("stopping instance")
                                    self.client.stop_instances(InstanceIds=[self.instance_id])
                    else:
                        if simulate == True:
                            simulate_stop.append(self.instance_id)
                        else:
                            print("stopping instance")
                            self.client.stop_instances(InstanceIds=[self.instance_id])
                else:
                    if start_hour<=end_hour:
                        if int(current_time) < start_hour or int(current_time) > end_hour:
                            if simulate == True:
                                simulate_stop.append(self.instance_id)
                            else:
                                print("stopping instance")
                                self.client.stop_instances(InstanceIds=[self.instance_id])             
                    else:
                        time_stamps=[]
                        for i in range(start_hour,24):
                            time_stamps.append(i)
                        if current_time not in time_stamps:
                            if simulate == True:
                                simulate_stop.append(self.instance_id)
                            else:
                                print("stopping instance")
                                self.client.stop_instances(InstanceIds=[self.instance_id])
            else:
                print("Please enter a proper Schedule Tag Value")
                   

    def override(self, simulate, simulate_start, simulate_stop, instances, run_days):
        global current_time
        print("we are in override")
        override_value = ''
        for k in self.tags:
            if k['Key'] == 'Override':
                override_value = k['Value']
        
        res=self.client.describe_instances(InstanceIds=[self.instance_id])
        status=res['Reservations'][0]['Instances'][0]['State']['Name']
        
        if status == "stopping" or status == "pending":
            instances.append(self.instance_id)
            return
        if status == "stopped":
            ########################################################
            rex = re.compile("^[0-9]{4};[0-9]{4};utc;((([0-6],){0,}[0-6]-[0-6])|([0-6]-[0-6](,[0-6]){0,})|(([0-6],){0,}[0-6])|([0-6]-[0-6])|all)$")
            if rex.match(override_value):
                timestamp=self.time_split(override_value,';')
                start_hour= int(timestamp[0][:2])
                end_hour=int(timestamp[1][:2])
                if timestamp[3] == 'all':
                    run_days = [0,1,2,3,4,5,6]
                else:
                    for i in timestamp[3].split(","):
                        if '-' in i:
                            start,stop = i.split("-")
                            for j in range(7):
                                day = (int(start) + j)%7
                                if day == int(stop):
                                    run_days.append(day)
                                    break
                                else:
                                    run_days.append(day)
                        else:
                            run_days.append(int(i))
                    #########################################################
                if int(strftime("%w")) in run_days:
                    if start_hour<=end_hour:
                        if int(current_time) >= start_hour and int(current_time) <= end_hour:
                            if simulate == True:
                                simulate_start.append(self.instance_id)
                            else:
                                print("starting instance")
                                self.client.start_instances(InstanceIds=[self.instance_id])               
                    else:
                        time_stamps=[]
                        for i in range(start_hour,24):
                            time_stamps.append(i)
                        for i in range(0,end_hour+1):
                            time_stamps.append(i)
                        if current_time in time_stamps:
                            if simulate == True:
                                simulate_start.append(self.instance_id)
                            else:
                                print("starting instance")
                                self.client.start_instances(InstanceIds=[self.instance_id])
            else:
                print("Please enter a proper Override Tag Value")

        elif status == 'running':
            rex = re.compile("^[0-9]{4};[0-9]{4};utc;((([0-6],){0,}[0-6]-[0-6])|([0-6]-[0-6](,[0-6]){0,})|(([0-6],){0,}[0-6])|([0-6]-[0-6])|all)$")
            if rex.match(override_value):
                timestamp=self.time_split(override_value,';')
                start_hour= int(timestamp[0][:2])
                end_hour=int(timestamp[1][:2])
                if timestamp[3] == 'all':
                    run_days = [0,1,2,3,4,5,6]
                else:
                    for i in timestamp[3].split(","):
                        if '-' in i:
                            start,stop = i.split("-")
                            for j in range(7):
                                day = (int(start) + j)%7
                                if day == int(stop):
                                    run_days.append(day)
                                    break
                                else:
                                    run_days.append(day)
                        else:
                            run_days.append(int(i))
                    #########################################################
                if int(strftime("%w")) not in run_days:
                    k = int(strftime("%w"))-1
                    if k == -1:
                        k = 6
                    if k in run_days:
                        if start_hour>end_hour:
                            time_stamps=[]
                            for i in range(0,end_hour+1):
                                time_stamps.append(i)
                            if current_time not in time_stamps:
                                if simulate == True:
                                    simulate_stop.append(self.instance_id)
                                else:
                                    print("stopping instance")
                                    self.client.stop_instances(InstanceIds=[self.instance_id])
                    else:
                        if simulate == True:
                            simulate_stop.append(self.instance_id)
                        else:
                            print("stopping instance")
                            self.client.stop_instances(InstanceIds=[self.instance_id])
                else:
                    if start_hour<=end_hour:
                        if int(current_time) < start_hour or int(current_time) > end_hour:
                            if simulate == True:
                                simulate_stop.append(self.instance_id)
                            else:
                                print("stopping instance")
                                self.client.stop_instances(InstanceIds=[self.instance_id])
                    else:
                        time_stamps=[]
                        for i in range(start_hour,24):
                            time_stamps.append(i)
                        if current_time not in time_stamps:
                            if simulate == True:
                                simulate_stop.append(self.instance_id)
                            else:
                                print("stopping instance")
                                self.client.stop_instances(InstanceIds=[self.instance_id])
            else:
                print("Please enter a proper Override Tag Value")
 

    def time_split(self,input_time,x):
        splitted=input_time.split(x)
        return splitted
                        
class EC2(Client,object):
    
    def __init__(self,aws_profile=None,aws_default_region=None):
        super(EC2, self).__init__(aws_profile=aws_profile,aws_default_region=aws_default_region)
        self.client = self.session.client('ec2')
    
    def _describe_instances(self, simulate, simulate_start, simulate_stop, instances):
        list_inst = []
        pager = self.client.get_paginator('describe_instances')
        for page in pager.paginate():
            for r in page['Reservations']:
                for i in r['Instances']:
                    if i['State']['Name']:
                        if i['State']['Name'] not in ['terminated']:
                            if i['Tags']:
                                for j in i['Tags']:
                                    if j['Key'].lower() == 'auto-start-stop' and j['Value'].lower() == 'true':
                                        list_inst.append(i)
        
        if len(list_inst) == 0:
            print("No instance with Auto-Start-Stop Tag as true")
            return

        for i in list_inst:
            Ec2Tags(self.client, simulate, i, simulate_start, simulate_stop, instances)
        
        if len(instances) != 0:
            print("These Instances are either in Stopping or Pending State while running lambda so no changes are made in these")
            print(instances)

        if simulate == True:
            print("Instances that will be started are : ")
            print(simulate_start)
            print("Instances that will be stopped are : ")
            print(simulate_stop)
    
    def list1(self, simulate = False):
        simulate_start = []
        simulate_stop = []
        instances = []
        return self._describe_instances(simulate, simulate_start, simulate_stop, instances)