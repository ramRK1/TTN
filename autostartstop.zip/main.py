from modules.ec2 import EC2
from modules.ecs import ECS
from modules.rds import RDS
from modules.autoscale import AutoScale

def lambda_handler(event, context):

    EC2obj = EC2()
    # ECSobj = ECS()
    # RDSobj = RDS()
    # AutoScaleobj = AutoScale()

    EC2obj.list1(simulate = True)
    # ECSobj.list1()
    # RDSobj.list1()
    # AutoScaleobj.list1()