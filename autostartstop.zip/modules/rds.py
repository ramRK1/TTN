from .client import Client
import os
import re
from time import strftime
import time
flag = 0
current_time = int(strftime("%H"))
class RDSTags:
    def __init__(self, client,arn):
    
        self.client = client
        self.arn=arn
        self.after_id=self.tag_check()

    def tag_check(self):
        global flag
        page=self.client.list_tags_for_resource(ResourceName=self.arn)
        for i in page['TagList']:
            if i['Key'] == 'AutoStartStop' and i['Value'] == 'true':
                for k in page['TagList']:
                    if k['Key'] == 'Override' or k['Key'] == 'Schedule':
                        flag = flag + 1
                        #print("flag = ", flag)
                for k in page['TagList']:
                    if k['Key'] == 'Override':
                        self.override()
                    if k['Key'] == 'Schedule':
                        res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                        if res['DBInstances'][0]['DBInstanceStatus'] !='available' and res['DBInstances'][0]['DBInstanceStatus'] !='creating':
                            rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                            if rex.match(k['Value']):
                                timestamp=self.time_split(k['Value'],'_')
                                now=self.time_split(timestamp[0],':')
                                start_hour=int(now[0])
                                end_hour=int(now[1])
                                week=self.time_split(timestamp[1],'-')
                                startweek=int(week[0])
                                endweek=int(week[1])
                                if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                    if start_hour<=end_hour:
                                        if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                            if res['DBInstances'][0]['DBInstanceStatus'] !='available' and res['DBInstances'][0]['DBInstanceStatus'] !='creating':
                                                #print(self.arn.split(':')[6],"schedule start")
                                                self.client.start_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                        else:
                                            if flag == 2:
                                                #print("Checking Override")
                                                for x in page['TagList']:
                                                    if x['Key']=='Override':
                                                        timestamp1=self.time_split(x['Value'],'_')
                                                        #print(timestamp1)
                                                        now1=self.time_split(timestamp1[0],':')
                                                        start_hour1=int(now1[0])
                                                        end_hour1=int(now1[1])
                                                        #print(x['Value'],start_hour1,end_hour1)
                                                        if start_hour1<=end_hour1:
                                                            time_arr=[]
                                                            for i in range(start_hour1,end_hour1+1):
                                                                time_arr.append(i)
                                                            if int(current_time) not in time_arr:
                                                                res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                                if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                    #print(self.arn.split(':')[6],"Schedule stop")
                                                                    self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                                        else:
                                                            #print("2 day format")
                                                            time_arr=[]
                                                            for i in range(start_hour1,24):
                                                                time_arr.append(i)
                                                            for i in range(0,end_hour1+1):
                                                                time_arr.append(i)
                                                            #print(time_arr)
                                                            if int(current_time) not in time_arr:
                                                                res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                                if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                    #print(self.arn.split(':')[6],"Schedule stop")
                                                                    self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                    else:
                                        time_stamps=[]
                                        for i in range(start_hour,24):
                                            time_stamps.append(i)
                                        for i in range(0,end_hour+1):
                                            time_stamps.append(i)
                                        #print(time_stamps)
                                        #print("Current time", current_time)
                                        if current_time in time_stamps:
                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                            if res['DBInstances'][0]['DBInstanceStatus'] !='available' and res['DBInstances'][0]['DBInstanceStatus'] !='creating':
                                                #print("Not running. Going to start")
                                                self.client.start_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                        else:
                                            if flag == 2:
                                                #print("Checking Override")
                                                for x in page['TagList']:
                                                    if x['Key']=='Override':
                                                        timestamp=self.time_split(x['Value'],'_')
                                                        now1=self.time_split(timestamp[0],':')
                                                        start_hour1=int(now[0])
                                                        end_hour1=int(now[1])
                                                        if start_hour1<=end_hour1:
                                                            time_arr=[]
                                                            for i in range(start_hour1,end_hour1+1):
                                                                time_arr.append(i)
                                                            if int(current_time) not in time_arr:   
                                                                res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                                if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                    #print(self.arn.split(':')[6],"schedule stop")
                                                                    self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                                        else:
                                                            time_arr=[]
                                                            for i in range(start_hour1,24):
                                                                time_arr.append(i)
                                                            for i in range(0,end_hour1+1):
                                                                time_arr.append(i)
                                                            #print(time_arr)
                                                            if int(current_time) not in time_arr:
                                                                res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                                if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                    #print(self.arn.split(':')[6],"schedule stop")
                                                                    self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                else:
                                    res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                    if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                        self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])

    def override(self):
        #global flag
        #if status == 'stopped':
        page=self.client.list_tags_for_resource(ResourceName=self.arn)
        for j in page['TagList']:
            if j['Key'] == 'AutoStartStop' and j['Value'] == 'true':
                for k in page['TagList']:
                    if k['Key'] == 'Override':
                        rex = re.compile("^[0-9][0-9]:[0-9][0-9]_[0-9]-[0-9]$")
                        if rex.match(k['Value']):
                            timestamp=self.time_split(k['Value'],'_')
                            now=self.time_split(timestamp[0],':')
                            start_hour=int(now[0])
                            end_hour=int(now[1])
                            week=self.time_split(timestamp[1],'-')
                            startweek=int(week[0])
                            endweek=int(week[1])
                            if int(strftime("%w")) >= startweek and int(strftime("%w")) <= endweek:
                                if start_hour<=end_hour:
                                    if int(current_time) >= start_hour and int(current_time) <= end_hour:
                                        res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                        if res['DBInstances'][0]['DBInstanceStatus'] !='available' and res['DBInstances'][0]['DBInstanceStatus'] !='creating':
                                            #print(self.arn.split(':')[6],"override start")
                                            self.client.start_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                    else:
                                        if flag == 2:
                                            #print("Checking Schedule")
                                            for x in page['TagList']:
                                                if x['Key']=='Schedule':
                                                    timestamp1=self.time_split(x['Value'],'_')
                                                    #print(timestamp1)
                                                    now1=self.time_split(timestamp1[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    #print(x['Value'],start_hour1,end_hour1)
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr:
                                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                            if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                #print(self.arn.split(':')[6],"override stop")
                                                                self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])    
                                                    else:
                                                        #print("2 day format")
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                            if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                #print(self.arn.split(':')[6],"override stop")
                                                                self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                else:
                                    time_stamps=[]
                                    for i in range(start_hour,24):
                                        time_stamps.append(i)
                                    for i in range(0,end_hour+1):
                                        time_stamps.append(i)
                                    #print(time_stamps)

                                    if current_time in time_stamps:
                                        res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                        if res['DBInstances'][0]['DBInstanceStatus'] !='available' and res['DBInstances'][0]['DBInstanceStatus'] !='creating':
                                            self.client.start_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                                    else:
                                        if flag == 2:
                                            #print("Checkinig Schedule")
                                            for x in page['TagList']:
                                                if x['Key']=='Schedule':
                                                    timestamp=self.time_split(x['Value'],'_')
                                                    now1=self.time_split(timestamp[0],':')
                                                    start_hour1=int(now1[0])
                                                    end_hour1=int(now1[1])
                                                    if start_hour1<=end_hour1:
                                                        time_arr=[]
                                                        for i in range(start_hour1,end_hour1+1):
                                                            time_arr.append(i)
                                                        if int(current_time) not in time_arr: 
                                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                            if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                #print(self.arn.split(':')[6],"override stop")
                                                                self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])    
                                                    else:
                                                        time_arr=[]
                                                        for i in range(start_hour1,24):
                                                            time_arr.append(i)
                                                        for i in range(0,end_hour1+1):
                                                            time_arr.append(i)
                                                        #print(time_arr)
                                                        if int(current_time) not in time_arr:
                                                            res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                                            if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                                                #print(self.arn.split(':')[6],"override stop")
                                                                self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
                            else:
                                res=self.client.describe_db_instances(DBInstanceIdentifier=self.arn.split(':')[6])
                                if res['DBInstances'][0]['DBInstanceStatus'] =='available':
                                    self.client.stop_db_instance(DBInstanceIdentifier=self.arn.split(':')[6])
    
    def time_split(self,input_time,x):
        splitted=input_time.split(x)
        return splitted
                        
class RDS(Client,object):
    
    def __init__(self,aws_profile=None,aws_default_region=None):
        super(RDS, self).__init__(aws_profile=aws_profile,aws_default_region=aws_default_region)
        self.client = self.session.client('rds')
    
    def _describe_db_instances(self):
        pager = self.client.get_paginator('describe_db_instances')
        for page in pager.paginate():
            for i in page['DBInstances']:
                if i['DBInstanceStatus'] in ['available','stopped']:
                    RDSTags(self.client,i['DBInstanceArn'])
    
    def list1(self):
        return self._describe_db_instances()