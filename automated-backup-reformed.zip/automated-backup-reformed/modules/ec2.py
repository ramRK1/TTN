#Maintainer Bhagvatula Nipun && Ram Kamra
from .client import Client
import datetime
import copy
import boto3

class EC2Instance:

    def __init__(self, client, info, simulate):
        self.client = client
        self.instance_id = info.get('InstanceId')
        self.tags = info.get('Tags')
        if simulate == False:
            print(self.tags)
        self.retention = self.get_retention()
        self.frequency = self.get_frequency()
        self.backup_date = self.get_date(simulate)
        self.sync = self.snapshot_delete(simulate)
        self.ami_id = self.create_ami(simulate)
        self.bkpParams = self.backup_params()
        self.retention_checker = self.retention_check(simulate)

    def get_date(self, simulate):

        date = ''
        for tag in self.tags:
            if tag['Key'] == 'BackupDate' :
                date = tag['Value']
                break
            else:
                date = datetime.datetime.utcnow().strftime('%Y-%m-%d')
                if simulate == False:
                    tag_response = self.client.create_tags(
                        Resources=[str(self.instance_id)],
                        Tags=[
                            {
                                'Key': 'BackupDate',
                                'Value': str(date)
                            },
                        ],
                    )
        return date
    
    def get_frequency(self):

        freq = ''
        for tag in self.tags:
            if tag['Key'] == 'Frequency' :
                freq = tag['Value']
                break
            else:
                freq = 1
        return freq

    def get_retention(self):

        ret = ''
        for tag in self.tags:
            if tag['Key'] == 'Retention':
                ret =  tag['Value']
                break
            else:
                ret = 7
        return  ret

    def backup_params(self):
        print('InstanceID: {}, Frequency: {}, Retention: {}'.format(self.instance_id,self.frequency,self.retention))
        return {'InstanceID': self.instance_id,
                'Frequency': self.frequency, 'Retention': self.retention}

    def snapshot_delete(self, simulate):
        snapshots = []
        for response in self.client.get_paginator('describe_snapshots').paginate(Filters=[{'Name': 'tag:automated-backup-delta','Values': ['true']}],OwnerIds=['self']):
            snapshots = [snapshot['SnapshotId'] for snapshot in response['Snapshots']]
        if simulate == True:
            if len(snapshots) == 0:
                print("No snapshot will be deleted")
            else:
                print("These snapshots with following SnapshotIds will be deleted - ",end="")
                print(snapshots)
        else:
            if len(snapshots) > 0:
                for snap_id in snapshots:
                    self.client.delete_snapshot(SnapshotId=str(snap_id))
        return "Snapshots checked and deleted"

    def create_ami(self,simulate):
        if int(self.frequency) <= 0:
            print("Please set the frequency value greater than 0")
        else:
            now = datetime.datetime.utcnow()
            create_time = self.backup_date
            today = datetime.datetime.utcnow().strftime('%Y-%m-%d')
            instance_id = self.instance_id

            now = str(now).split()[0]
            built_days = (datetime.datetime.strptime(str(now), "%Y-%m-%d") - datetime.datetime.strptime(str(create_time), "%Y-%m-%d")).days + 1
            if simulate == True:
                if int(built_days) == 1:
                    print("A BackupDate tag on instance with InstanceId : %s will be created with value as %s"%(instance_id,today))

            if int(built_days) % int(self.frequency) == 0 or int(built_days) == 1:
                if simulate == True:
                    print("Create an AMI: Automated Backup {} on {}".format(instance_id, today),end=" ")
                    print("with tag key = ManagedBy and Value = automated-backup as well as tags on the Snapshots also")
                    return
                else:
                    response = self.client.create_image(
                        InstanceId=instance_id,
                        Name='Automated Backup {} on {}'.format(instance_id, today),
                        NoReboot=True
                    )
    
                    tag_response = self.client.create_tags(
                        Resources=[
                            str(response['ImageId']),
                        ],
                        Tags=[
                            {
                                'Key': 'ManagedBy',
                                'Value': 'automated-backup'
                            },
                        ],
                    )
    
                    print ('Creating EC2 AMI with Id = {}'.format(response['ImageId']))
                    return response['ImageId']
        
        print("Image will not be created as per the frequency for today")
        return "Image will not be created as per the frequency for today"

    def retention_check(self,simulate):
        datelimit = datetime.datetime.utcnow() - datetime.timedelta(days=((int(self.retention)-1)*int(self.frequency)))
        if simulate == False:
            print(datelimit)
        
        ami_response = self.client.describe_images(
            Filters=[
                {
                    'Name': 'tag:'+'ManagedBy',
                    'Values': ['automated-backup']
                }
            ])
        if simulate == False:
            print(ami_response)

        if len(ami_response['Images']) <= int(self.retention):
            if simulate == True:
                print("Retention is checked as per the values the work is done")
            return
        
        for i in ami_response['Images']:
            response = ''
            creationDate = i['CreationDate'].split("T")
            ami_id = i['ImageId']
            ExpectedDate = datetime.datetime.strptime(creationDate[0], "%Y-%m-%d")

            tag_response = self.client.describe_tags(
                Filters=[
                    {
                        'Name': 'resource-id',
                        'Values': [ami_id]
                    }
                ])

            for tag in tag_response['Tags']:
                if tag['Key'] == 'ManagedBy' and tag['Value'] == 'automated-backup':
                    if ExpectedDate < datelimit:
                        if simulate == True:
                            print("Image with ImageId : %s will be deleted as per the retention "%ami_id)
                        else:
                            self.client.deregister_image(ImageId=ami_id)
                    else:
                        if simulate == True:
                            print("No Image be deregistered and No Snapshots will be deleted")

            for device in i['BlockDeviceMappings']:
                
                snap_id = device['Ebs']['SnapshotId']
                snap_tag_response = self.client.describe_snapshots(SnapshotIds=[snap_id])

                for snaps in snap_tag_response['Snapshots']:
                    try:
                        for tag in snaps['Tags']:
                            if tag['Key'] == 'ManagedBy' and tag['Value'] == 'automated-backup':
                                if ExpectedDate < datelimit:
                                    if simulate == True:
                                        print("Snapshot with SnapshotId : %s will be deleted as per the retention on next run"%snap_id)
                                    else:
                                        self.client.create_tags(
                                            Resources=[str(snap_id)],
                                            Tags=[
                                                {
                                                    'Key': 'automated-backup-delta',
                                                    'Value': 'true'
                                                },
                                            ],
                                        )
                    except:
                        pass
        if simulate == True:
            print("Retention is checked as per the values the work is done")
        return "Retention is checked as per the values the work is done"

class EC2(Client, object):

    def __init__(self, aws_profile=None, aws_default_region=None):
        super(EC2, self).__init__(aws_profile=aws_profile,
                                  aws_default_region=aws_default_region)
        self.client = self.session.client('ec2')

    def get_instance(self,simulate):
        ec2s = []
        instances_list = []
        pager = self.client.get_paginator('describe_instances')
        for page in pager.paginate(Filters=[
            {
                'Name': 'tag:'+'Backup',
                'Values': ['true']
            }]):
            instances_list.append(page)

        for page in instances_list:
            for r in (page["Reservations"]):
                for i in r['Instances']:
                    if i['State']['Name']:
                        if i['State']['Name'] not in ['terminated']:
                            ec2s.append(EC2Instance(self.client, i, simulate))
                            print("------------------------------------------------------")

        return  ec2s

    def listing(self,simulate=False):
        return self.get_instance(simulate)